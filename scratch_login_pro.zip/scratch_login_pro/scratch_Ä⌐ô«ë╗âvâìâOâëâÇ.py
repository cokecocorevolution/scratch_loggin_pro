import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

driver = webdriver.Chrome()
driver.get('https://scratch.mit.edu/explore/projects/all')
time.sleep

signin = driver.find_element_by_xpath('//*[@id="navigation"]/div/ul/li[8]')
signin.click()
time.sleep(0.5)

# ユーザー名を入力(xxxxxを自分のユーザー名に変更)
login_id = driver.find_element_by_xpath('//*[@id="frc-username-1088"]')
login_id.click()
login_id.send_keys("xxxxx")
time.sleep(0.5)

# パスワードを入力(xxxxxを自分のパスワードに変更)
login_pass = driver.find_element_by_xpath('//*[@id="frc-password-1088"]')
login_pass.click()
login_pass.send_keys("xxxxx")
time.sleep(0.5)

# サインインボタンをクリック
signin = driver.find_element_by_xpath('//*[@id="navigation"]/div/ul/li[8]/div/div/form/div[3]/button')
signin.click()
time.sleep(0.5)

